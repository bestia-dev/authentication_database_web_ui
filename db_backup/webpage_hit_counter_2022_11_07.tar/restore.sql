--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8 (Debian 13.8-1.pgdg110+1)
-- Dumped by pg_dump version 13.8 (Debian 13.8-0+deb11u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE webpage_hit_counter;
--
-- Name: webpage_hit_counter; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE webpage_hit_counter WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE webpage_hit_counter OWNER TO admin;

\connect webpage_hit_counter

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: a1_drop_function_any_param(name); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.a1_drop_function_any_param(_name name) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
   _sql text;
   _functions_dropped int;
begin
   select count(*)::int
        , 'DROP function ' || string_agg(oid::regprocedure::text, '; DROP function ')
   from   pg_catalog.pg_proc
   where  proname = _name
   and    pg_function_is_visible(oid)  -- restrict to current search_path
   into   _functions_dropped, _sql;     -- count only returned if subsequent DROPs succeed

   if _functions_dropped > 0 then       -- only if function(s) found
     execute _sql;
     return _sql;
   end if;
   return '';
end;
$$;


ALTER FUNCTION public.a1_drop_function_any_param(_name name) OWNER TO admin;

--
-- Name: a2_migrate_column(name, name, text, text, text); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.a2_migrate_column(_table name, _column name, _type text, _default text, _not_null text) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
   _default_txt text := case when _default <> '' then format(' default(%s)', _default) else '' end;
   _not_null_txt text := case when _not_null <> '' then format(' %s', _not_null) else '' end;
   _definition text := format('%s%s%s', _type, _default_txt, _not_null_txt);
   _object_name text :=  format('%I.%I', _table, _column);
   _old_definition text;   
   _installed_definition text;
   _installed_type text;
   _installed_default text;
   _installed_not_null text;
   _x_void text;
begin

   -- I can FORCE here only certain data types with explicit names. The same set of data types I can use inside the Rust code.
   -- Postgres is a mess with datatypes. You can call it integer, int4, int and what not. This is bad. Really bad if you want to analyze anything.
   -- I will FORCE here an exact nomenclature of a limited set of data types. The most technical and exact one. They call it 'udt_name'.

   if not (_type like 'varchar(%)' or _type in ('text','int4','bool','timestamp')) then
      RAISE EXCEPTION 'Data type %s in not allowed in this limited set of types: varchar(x), text, int4, bool, timestamp.', _type;
   end if;

   if not (_not_null = 'not null') then
      RAISE EXCEPTION 'Parameter _not_null can only contain the phrase "not null", not the phrase "%s".', _not_null;
   end if;


   if not exists(select * from a2_source_code a where a.object_name = _object_name) then
      if exists(select * from information_schema.columns c where c.table_schema = 'public' and c.table_name=_table and c.column_name=_column) then
         select d.installed_definition into _installed_definition from a1_list_all_table_field_definition d where d.table_name=_table and d.column_name=_column ;
         if _installed_definition <> _definition then
            return format('ERROR: Installed definition is different:    %s   %s', _installed_definition, _definition);
         end if;
      else
         execute format('alter table %I add COLUMN %I %s;', _table, _column, _definition);
      end if;

      insert into a2_source_code (object_name, definition)
      values (_object_name, _definition);

      return format('Inserted column: %I', _object_name);
   else
      select a.definition 
      into _old_definition
      from a2_source_code a
      where a.object_name = _object_name;

      if _definition <> _old_definition then
         if not exists(select * from information_schema.columns c where c.table_schema = 'public' and c.table_name=_table and c.column_name=_column) then
            return format('ERROR: Column "%s" exists in a2_source_code, but is not already installed ?!?', _object_name);
         end if;
         
         select d.installed_type, d.installed_default, d.installed_not_null
         into _installed_type, _installed_default, _installed_not_null
         from a1_list_all_table_field_definition d where d.table_name=_table and d.column_name=_column ;

         if _installed_type <> _type then
            execute format('alter table %I alter COLUMN %I TYPE %s;', _table, _column, _type);
         end if;

         if _installed_default <> _default then
            execute format('alter table %I alter COLUMN %I SET DEFAULT %s;', _table, _column, _default);
         end if;         

         if _installed_not_null <> _not_null then
            if _not_null = '' then
               execute format('alter table %I alter COLUMN %I DROP not null;', _table, _column);
            else
               execute format('alter table %I alter COLUMN %I SET %s;', _table, _column, _not_null);
            end if;
         end if;  

         update a2_source_code
         set definition = _definition
         where object_name = _object_name;

         return format('Updated column: %I', _object_name);
      end if;

   end if;
   return format('Up to date Column: %I', _object_name);
end;
$$;


ALTER FUNCTION public.a2_migrate_column(_table name, _column name, _type text, _default text, _not_null text) OWNER TO admin;

--
-- Name: a2_migrate_constraint_foreign(name, name, name, name); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.a2_migrate_constraint_foreign(_table name, _column name, _table_ref name, _column_ref name) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare 
    _constraint_name text := format('%I_foreign_%I', _table, _column);
    _ddl_statement text := format('alter table %I add constraint %I foreign key (%I) references %I (%I)', _table, _constraint_name, _column, _table_ref, _column_ref );
begin

    if not exists(
            select *
            from a1_list_all_constraints_foreign c            
            where c.table_name = _table and c.constraint_name = _constraint_name
    ) then        
        execute _ddl_statement;
        return format('%s', _ddl_statement);
    end if;
    return format('Up to date Constraint: %I', _constraint_name);
end;
$$;


ALTER FUNCTION public.a2_migrate_constraint_foreign(_table name, _column name, _table_ref name, _column_ref name) OWNER TO admin;

--
-- Name: a2_migrate_constraint_unique(name, name); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.a2_migrate_constraint_unique(_table name, _column name) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare 
    _constraint_name text := format('%I_uniq_%I', _table, _column);
    _ddl_statement text := format('alter table %I add constraint %I unique (%I)', _table, _constraint_name, _column );
begin

    if not exists(
            select *
            from a1_list_all_constraints_unique c
            where c.table_name = _table and c.constraint_name = _constraint_name
    ) then        
        execute _ddl_statement;
        return format('%s', _ddl_statement);
    end if;
    return format('Up to date Constraint: %I', _constraint_name);
end;
$$;


ALTER FUNCTION public.a2_migrate_constraint_unique(_table name, _column name) OWNER TO admin;

--
-- Name: a2_migrate_function(name, text); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.a2_migrate_function(_object_name name, _definition text) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
   _old_definition text;
   _x_void text;
begin

   if not exists(select * from a2_source_code a where a.object_name = _object_name) then
      if exists(select * from a1_list_all_functions p where p.routine_name=_object_name) then
         select a1_drop_function_any_param(_object_name) into _x_void;
      end if;

      execute _definition;

      insert into a2_source_code (object_name, definition)
      values (_object_name, _definition);
      return format('Inserted function: %I', _object_name);
   else
      select a.definition 
      into _old_definition
      from a2_source_code a
      where a.object_name = _object_name;

      if _definition <> _old_definition then
         if exists(select * from a1_list_all_functions p where p.routine_name=_object_name) then
            select a1_drop_function_any_param(_object_name) into _x_void;
         end if;
         
         execute _definition;

         update a2_source_code
         set definition = _definition
         where object_name = _object_name;

         return format('Updated function: %I', _object_name);
      end if;

   end if;
return format('Up to date Function: %I', _object_name);
end;
$$;


ALTER FUNCTION public.a2_migrate_function(_object_name name, _definition text) OWNER TO admin;

--
-- Name: a2_migrate_table(name, text); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.a2_migrate_table(_object_name name, _definition text) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
   _old_definition text;
   _x_void text;
begin

   if not exists(select * from a2_source_code a where a.object_name = _object_name) then
      if exists(select * from a1_list_all_tables a where a.table_name=_object_name) then
         -- do nothing. Just insert into a2_source_code
      else
         execute _definition;
      end if;

      insert into a2_source_code (object_name, definition)
      values (_object_name, _definition);

      return format('Inserted table (pk): %I', _object_name);
   else
      select a.definition 
      into _old_definition
      from a2_source_code a
      where a.object_name = _object_name;

      if _definition <> _old_definition then
         if exists(select * from a1_list_all_tables a where a.table_name=_object_name) then
            return format('ERROR: Table (pk) is different and cannot change: %I   %s   %s', _object_name, _definition, _old_definition);
         else
            execute _definition;
         end if;
                  
         update a2_source_code
         set definition = _definition
         where object_name = _object_name;

         return format('Updated table (pk): %I', _object_name);
      end if;

   end if;
   return format('Up to date Table (pk): %I', _object_name);
end;
$$;


ALTER FUNCTION public.a2_migrate_table(_object_name name, _definition text) OWNER TO admin;

--
-- Name: a2_migrate_view(name, text); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.a2_migrate_view(_object_name name, _definition text) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
   _old_definition text;
   _x_void text;
begin

   if not exists(select * from a2_source_code a where a.object_name = _object_name) then
      if exists(select * from a1_list_all_views v where v.view_name=_object_name) then
         execute format('DROP VIEW %I CASCADE', _object_name);
      end if;

      execute _definition;

      insert into a2_source_code (object_name, definition)
      values (_object_name, _definition);
      return format('Inserted view: %I', _object_name);
   else
      select a.definition 
      into _old_definition
      from a2_source_code a
      where a.object_name = _object_name;

      if _definition <> _old_definition then
         if exists(select * from a1_list_all_views v where v.view_name=_object_name) then
            execute format('DROP VIEW %I CASCADE', _object_name);
         end if;
         
         execute _definition;

         update a2_source_code
         set definition = _definition
         where object_name = _object_name;

         return format('Updated view: %I', _object_name);
      end if;

   end if;
   return format('Up to date View: %I', _object_name);
end;
$$;


ALTER FUNCTION public.a2_migrate_view(_object_name name, _definition text) OWNER TO admin;

--
-- Name: a4_random_between(integer, integer); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.a4_random_between(_low integer, _high integer) RETURNS integer
    LANGUAGE plpgsql STRICT
    AS $$
begin

return floor(random()* (_high-_low + 1) + _low);

end;
$$;


ALTER FUNCTION public.a4_random_between(_low integer, _high integer) OWNER TO admin;

--
-- Name: b1_authn_signup_delete(character varying); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.b1_authn_signup_delete(_user_email character varying) RETURNS TABLE(deleted_rows integer)
    LANGUAGE plpgsql
    AS $$
declare
begin

delete from b1_authn_signup a
where a.user_email = _user_email;

return query 
select 1 as deleted_rows;

end; 
$$;


ALTER FUNCTION public.b1_authn_signup_delete(_user_email character varying) OWNER TO admin;

--
-- Name: b1_authn_signup_insert(character varying, character varying, boolean); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.b1_authn_signup_insert(_user_email character varying, _password_hash character varying, _verified boolean) RETURNS TABLE(user_email character varying, hit_count character varying, verified boolean, created_at timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
declare

begin

insert into b1_authn_signup(user_email, password_hash, verified)
values(_user_email,_password_hash, _verified);

return query 
select a.user_email, a.password_hash, a.verified, created_at
from b1_authn_signup a
where w.user_email=_user_email;

end; 
$$;


ALTER FUNCTION public.b1_authn_signup_insert(_user_email character varying, _password_hash character varying, _verified boolean) OWNER TO admin;

--
-- Name: b2_authn_login_show(character varying); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.b2_authn_login_show(_user_email character varying) RETURNS TABLE(authn_login_id integer, user_email character varying, password_hash character varying, failed_attempts integer, blocked boolean)
    LANGUAGE plpgsql
    AS $$
declare

begin

return query 
select  t.authn_login_id,
    t.user_email,
    t.password_hash,
    t.failed_attempts,
    t.blocked
from b2_authn_login t
where t.user_email = _user_email;

end; 
$$;


ALTER FUNCTION public.b2_authn_login_show(_user_email character varying) OWNER TO admin;

--
-- Name: c1_webpage_hits_delete(integer); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.c1_webpage_hits_delete(_id integer) RETURNS TABLE(deleted_rows integer)
    LANGUAGE plpgsql
    AS $$
declare
begin

delete from c1_hit_counter h
where h.webpage_id = _id;

delete from webpage w
where w.id = _id;

return query 
select 1 as deleted_rows;

end; 
$$;


ALTER FUNCTION public.c1_webpage_hits_delete(_id integer) OWNER TO admin;

--
-- Name: c1_webpage_hits_edit(integer); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.c1_webpage_hits_edit(_id integer) RETURNS TABLE(id integer, webpage character varying, hit_count integer)
    LANGUAGE plpgsql
    AS $$
declare
begin

return query 
select w.id, w.webpage, w.hit_count
from c1_webpage_hits w
where w.id=_id;

end; 
$$;


ALTER FUNCTION public.c1_webpage_hits_edit(_id integer) OWNER TO admin;

--
-- Name: c1_webpage_hits_insert(integer, character varying, integer); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.c1_webpage_hits_insert(_id integer, _webpage character varying, _hit_count integer) RETURNS TABLE(id integer, webpage character varying, hit_count integer)
    LANGUAGE plpgsql
    AS $$
declare

begin

insert into webpage ( "id", webpage)
values (_id, _webpage);

insert into c1_hit_counter(webpage_id, "count")
values(_id,_hit_count);

return query 
select w.id, w.webpage, w.hit_count
from c1_webpage_hits w
where w.id=_id;

end; 
$$;


ALTER FUNCTION public.c1_webpage_hits_insert(_id integer, _webpage character varying, _hit_count integer) OWNER TO admin;

--
-- Name: c1_webpage_hits_new(); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.c1_webpage_hits_new() RETURNS TABLE(id integer, webpage character varying, hit_count integer)
    LANGUAGE plpgsql
    AS $$
declare
begin
return query 

-- the id is random from one billion. that is enough for my simple tutorial.
select random_between(1, 1000000000) as id, 
'webpage short url'::varchar(100) as webpage, 
0 as hit_count;

end; 
$$;


ALTER FUNCTION public.c1_webpage_hits_new() OWNER TO admin;

--
-- Name: c1_webpage_hits_show(integer); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.c1_webpage_hits_show(_id integer) RETURNS TABLE(id integer, webpage character varying, hit_count integer)
    LANGUAGE plpgsql
    AS $$
declare
begin

return query 
select w.id, w.webpage, w.hit_count
from c1_webpage_hits w
where w.id=_id;

end; 
$$;


ALTER FUNCTION public.c1_webpage_hits_show(_id integer) OWNER TO admin;

--
-- Name: c1_webpage_hits_update(integer, character varying, integer); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.c1_webpage_hits_update(_id integer, _webpage character varying, _hit_count integer) RETURNS TABLE(id integer, webpage character varying, hit_count integer)
    LANGUAGE plpgsql
    AS $$
declare
begin

update webpage as w
set webpage = _webpage
where w.id = _id;

update c1_hit_counter as h
set count = _hit_count
where h.webpage_id=_id;

return query 
select W.id, W.webpage, W.hit_count
from c1_webpage_hits W
where W.id=_id;

end; 
$$;


ALTER FUNCTION public.c1_webpage_hits_update(_id integer, _webpage character varying, _hit_count integer) OWNER TO admin;

--
-- Name: a1_list_all_constraints_foreign; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a1_list_all_constraints_foreign AS
 SELECT (t.constraint_name)::name AS constraint_name,
    (k.table_name)::name AS table_name,
    (k.column_name)::name AS column_name,
    (c.table_name)::name AS table_name_ref,
    (c.column_name)::name AS column_name_ref
   FROM ((information_schema.table_constraints t
     JOIN information_schema.constraint_column_usage c ON (((c.constraint_name)::name = (t.constraint_name)::name)))
     JOIN information_schema.key_column_usage k ON (((k.constraint_name)::name = (t.constraint_name)::name)))
  WHERE (((t.constraint_schema)::name = 'public'::name) AND ((t.constraint_type)::text = 'FOREIGN KEY'::text));


ALTER TABLE public.a1_list_all_constraints_foreign OWNER TO admin;

--
-- Name: a1_list_all_constraints_unique; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a1_list_all_constraints_unique AS
 SELECT (t.constraint_name)::name AS constraint_name,
    (t.table_name)::name AS table_name,
    (c.column_name)::name AS column_name
   FROM (information_schema.table_constraints t
     JOIN information_schema.constraint_column_usage c ON (((c.constraint_name)::name = (t.constraint_name)::name)))
  WHERE (((t.constraint_schema)::name = 'public'::name) AND ((t.constraint_type)::text = 'UNIQUE'::text));


ALTER TABLE public.a1_list_all_constraints_unique OWNER TO admin;

--
-- Name: a1_list_all_function_input_params; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a1_list_all_function_input_params AS
 SELECT (r.routine_name)::name AS routine_name,
    (p.ordinal_position)::integer AS ordinal_position,
    (p.parameter_name)::name AS parameter_name,
    (p.udt_name)::name AS udt_name
   FROM (information_schema.routines r
     JOIN information_schema.parameters p ON ((((p.specific_name)::name = (r.specific_name)::name) AND ((p.parameter_mode)::text = 'IN'::text))))
  WHERE (((r.routine_schema)::name = 'public'::name) AND ((r.routine_type)::text = 'FUNCTION'::text))
  ORDER BY r.routine_name, p.ordinal_position;


ALTER TABLE public.a1_list_all_function_input_params OWNER TO admin;

--
-- Name: a1_list_all_functions; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a1_list_all_functions AS
 SELECT (t.routine_name)::name AS routine_name,
    (t.specific_name)::name AS specific_name,
    (t.type_udt_name)::name AS type_udt_name
   FROM information_schema.routines t
  WHERE (((t.routine_schema)::name = 'public'::name) AND ((t.routine_type)::text = 'FUNCTION'::text))
  ORDER BY t.routine_name;


ALTER TABLE public.a1_list_all_functions OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: a2_source_code; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.a2_source_code (
    object_name name NOT NULL,
    definition text NOT NULL
);


ALTER TABLE public.a2_source_code OWNER TO admin;

--
-- Name: a1_list_all_table_field_definition; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a1_list_all_table_field_definition AS
 SELECT (c.table_name)::name AS table_name,
    (c.column_name)::name AS column_name,
    s.definition AS souce_code_definition,
    format('%s%s%s%s'::text, c.udt_name,
        CASE
            WHEN ((c.udt_name)::name = 'varchar'::name) THEN format('(%s)'::text, c.character_maximum_length)
            ELSE ''::text
        END,
        CASE
            WHEN (c.column_default IS NOT NULL) THEN format(' default(%s)'::text, c.column_default)
            ELSE ''::text
        END,
        CASE
            WHEN ((c.is_nullable)::text = 'NO'::text) THEN ' not null'::text
            ELSE ''::text
        END) AS installed_definition,
    format('%s%s'::text, c.udt_name,
        CASE
            WHEN ((c.udt_name)::name = 'varchar'::name) THEN format('(%s)'::text, c.character_maximum_length)
            ELSE ''::text
        END) AS installed_type,
    format('%s'::text,
        CASE
            WHEN (c.column_default IS NOT NULL) THEN format('default(%s)'::text, c.column_default)
            ELSE ''::text
        END) AS installed_default,
    format('%s'::text,
        CASE
            WHEN ((c.is_nullable)::text = 'NO'::text) THEN ' not null'::text
            ELSE ''::text
        END) AS installed_not_null
   FROM ((information_schema.tables t
     JOIN information_schema.columns c ON (((c.table_name)::name = (t.table_name)::name)))
     LEFT JOIN public.a2_source_code s ON ((s.object_name = format('%I.%I'::text, c.table_name, c.column_name))))
  WHERE (((t.table_schema)::name = 'public'::name) AND ((t.table_type)::text = 'BASE TABLE'::text) AND ((c.ordinal_position)::integer > 1))
  ORDER BY t.table_name, c.ordinal_position;


ALTER TABLE public.a1_list_all_table_field_definition OWNER TO admin;

--
-- Name: a1_list_all_tables; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a1_list_all_tables AS
 SELECT (t.table_name)::name AS table_name
   FROM information_schema.tables t
  WHERE (((t.table_schema)::name = 'public'::name) AND ((t.table_type)::text = 'BASE TABLE'::text))
  ORDER BY t.table_name;


ALTER TABLE public.a1_list_all_tables OWNER TO admin;

--
-- Name: a1_list_all_view_fields; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a1_list_all_view_fields AS
 SELECT (t.table_name)::name AS view_name,
    (c.column_name)::name AS column_name,
    (c.udt_name)::name AS udt_name
   FROM (information_schema.tables t
     JOIN information_schema.columns c ON (((c.table_name)::name = (t.table_name)::name)))
  WHERE (((t.table_schema)::name = 'public'::name) AND ((t.table_type)::text = 'VIEW'::text))
  ORDER BY t.table_name, c.column_name;


ALTER TABLE public.a1_list_all_view_fields OWNER TO admin;

--
-- Name: a1_list_all_views; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a1_list_all_views AS
 SELECT (t.table_name)::name AS view_name
   FROM information_schema.views t
  WHERE ((t.table_schema)::name = 'public'::name)
  ORDER BY t.table_name;


ALTER TABLE public.a1_list_all_views OWNER TO admin;

--
-- Name: a3_check_function_overload; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a3_check_function_overload AS
 SELECT a1_list_all_functions.routine_name,
    (count(*))::integer AS count,
    format('select a1_drop_function_any_param(''%I'');'::text, a1_list_all_functions.routine_name) AS drop_statement
   FROM public.a1_list_all_functions
  GROUP BY a1_list_all_functions.routine_name
 HAVING (count(*) > 1);


ALTER TABLE public.a3_check_function_overload OWNER TO admin;

--
-- Name: a3_check_multi_column_foreign; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a3_check_multi_column_foreign AS
 SELECT a1_list_all_constraints_foreign.constraint_name,
    (count(*))::integer AS count
   FROM public.a1_list_all_constraints_foreign
  GROUP BY a1_list_all_constraints_foreign.constraint_name
 HAVING (count(*) > 1);


ALTER TABLE public.a3_check_multi_column_foreign OWNER TO admin;

--
-- Name: a3_check_multi_column_unique; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a3_check_multi_column_unique AS
 SELECT a1_list_all_constraints_unique.constraint_name,
    (count(*))::integer AS count
   FROM public.a1_list_all_constraints_unique
  GROUP BY a1_list_all_constraints_unique.constraint_name
 HAVING (count(*) > 1);


ALTER TABLE public.a3_check_multi_column_unique OWNER TO admin;

--
-- Name: a3_check_parameter_types; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a3_check_parameter_types AS
 SELECT a1_list_all_function_input_params.routine_name,
    a1_list_all_function_input_params.parameter_name,
    a1_list_all_function_input_params.udt_name
   FROM public.a1_list_all_function_input_params
  WHERE (a1_list_all_function_input_params.udt_name <> ALL (ARRAY['name'::name, 'text'::name, 'int4'::name, 'varchar'::name, 'bool'::name]));


ALTER TABLE public.a3_check_parameter_types OWNER TO admin;

--
-- Name: a3_check_table_field_type; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a3_check_table_field_type AS
 SELECT t.table_name,
    t.column_name,
    t.installed_type,
    t.souce_code_definition
   FROM public.a1_list_all_table_field_definition t
  WHERE ((t.installed_type <> ALL (ARRAY['name'::text, 'text'::text, 'int4'::text, 'timestamp'::text, 'bool'::text])) AND (t.installed_type !~~ 'varchar(%)'::text));


ALTER TABLE public.a3_check_table_field_type OWNER TO admin;

--
-- Name: a3_check_view_field_type; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.a3_check_view_field_type AS
 SELECT t.view_name,
    t.column_name,
    t.udt_name
   FROM public.a1_list_all_view_fields t
  WHERE (t.udt_name <> ALL (ARRAY['name'::name, 'text'::name, 'int4'::name, 'timestamp'::name, 'bool'::name, 'varchar'::name]));


ALTER TABLE public.a3_check_view_field_type OWNER TO admin;

--
-- Name: b1_authn_signup; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.b1_authn_signup (
    user_email character varying(100) NOT NULL,
    password_hash character varying(100) NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.b1_authn_signup OWNER TO admin;

--
-- Name: b2_authn_login; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.b2_authn_login (
    authn_login_id integer NOT NULL,
    user_email character varying(100) NOT NULL,
    password_hash character varying(100) NOT NULL,
    failed_attempts integer DEFAULT 0 NOT NULL,
    blocked boolean DEFAULT false NOT NULL
);


ALTER TABLE public.b2_authn_login OWNER TO admin;

--
-- Name: b2_authn_login_authn_login_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.b2_authn_login_authn_login_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.b2_authn_login_authn_login_id_seq OWNER TO admin;

--
-- Name: b2_authn_login_authn_login_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.b2_authn_login_authn_login_id_seq OWNED BY public.b2_authn_login.authn_login_id;


--
-- Name: c1_hit_counter; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.c1_hit_counter (
    id integer NOT NULL,
    webpage_id integer NOT NULL,
    count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.c1_hit_counter OWNER TO admin;

--
-- Name: c1_hit_counter_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.c1_hit_counter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.c1_hit_counter_id_seq OWNER TO admin;

--
-- Name: c1_hit_counter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.c1_hit_counter_id_seq OWNED BY public.c1_hit_counter.id;


--
-- Name: c1_webpage; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.c1_webpage (
    id integer NOT NULL,
    webpage character varying(100) NOT NULL
);


ALTER TABLE public.c1_webpage OWNER TO admin;

--
-- Name: c1_webpage_hits; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.c1_webpage_hits AS
 SELECT w.id,
    w.webpage,
    h.count AS hit_count
   FROM (public.c1_webpage w
     JOIN public.c1_hit_counter h ON ((h.webpage_id = w.id)))
  WHERE (w.id = h.webpage_id)
  ORDER BY w.webpage;


ALTER TABLE public.c1_webpage_hits OWNER TO admin;

--
-- Name: c1_webpage_hits_list; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.c1_webpage_hits_list AS
 SELECT w.id,
    w.webpage,
    w.hit_count
   FROM public.c1_webpage_hits w;


ALTER TABLE public.c1_webpage_hits_list OWNER TO admin;

--
-- Name: b2_authn_login authn_login_id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.b2_authn_login ALTER COLUMN authn_login_id SET DEFAULT nextval('public.b2_authn_login_authn_login_id_seq'::regclass);


--
-- Name: c1_hit_counter id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.c1_hit_counter ALTER COLUMN id SET DEFAULT nextval('public.c1_hit_counter_id_seq'::regclass);


--
-- Data for Name: a2_source_code; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.a2_source_code (object_name, definition) FROM stdin;
\.
COPY public.a2_source_code (object_name, definition) FROM '$$PATH$$/3121.dat';

--
-- Data for Name: b1_authn_signup; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.b1_authn_signup (user_email, password_hash, verified, created_at) FROM stdin;
\.
COPY public.b1_authn_signup (user_email, password_hash, verified, created_at) FROM '$$PATH$$/3122.dat';

--
-- Data for Name: b2_authn_login; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.b2_authn_login (authn_login_id, user_email, password_hash, failed_attempts, blocked) FROM stdin;
\.
COPY public.b2_authn_login (authn_login_id, user_email, password_hash, failed_attempts, blocked) FROM '$$PATH$$/3124.dat';

--
-- Data for Name: c1_hit_counter; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.c1_hit_counter (id, webpage_id, count) FROM stdin;
\.
COPY public.c1_hit_counter (id, webpage_id, count) FROM '$$PATH$$/3127.dat';

--
-- Data for Name: c1_webpage; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.c1_webpage (id, webpage) FROM stdin;
\.
COPY public.c1_webpage (id, webpage) FROM '$$PATH$$/3125.dat';

--
-- Name: b2_authn_login_authn_login_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.b2_authn_login_authn_login_id_seq', 1, true);


--
-- Name: c1_hit_counter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.c1_hit_counter_id_seq', 1, false);


--
-- Name: a2_source_code a_source_code_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.a2_source_code
    ADD CONSTRAINT a_source_code_pkey PRIMARY KEY (object_name);


--
-- Name: b2_authn_login authn_login_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.b2_authn_login
    ADD CONSTRAINT authn_login_pkey PRIMARY KEY (authn_login_id);


--
-- Name: b1_authn_signup authn_signup_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.b1_authn_signup
    ADD CONSTRAINT authn_signup_pkey PRIMARY KEY (user_email);


--
-- Name: b2_authn_login b2_authn_login_uniq_user_email; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.b2_authn_login
    ADD CONSTRAINT b2_authn_login_uniq_user_email UNIQUE (user_email);


--
-- Name: c1_webpage c1_webpage_uniq_webpage; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.c1_webpage
    ADD CONSTRAINT c1_webpage_uniq_webpage UNIQUE (webpage);


--
-- Name: c1_hit_counter hit_counter_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.c1_hit_counter
    ADD CONSTRAINT hit_counter_pkey PRIMARY KEY (id);


--
-- Name: c1_webpage webpage_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.c1_webpage
    ADD CONSTRAINT webpage_pkey PRIMARY KEY (id);


--
-- Name: c1_hit_counter c1_hit_counter_foreign_webpage_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.c1_hit_counter
    ADD CONSTRAINT c1_hit_counter_foreign_webpage_id FOREIGN KEY (webpage_id) REFERENCES public.c1_webpage(id);


--
-- PostgreSQL database dump complete
--

