--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8 (Debian 13.8-1.pgdg110+1)
-- Dumped by pg_dump version 13.8 (Debian 13.8-0+deb11u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE webpage_hit_counter;
--
-- Name: webpage_hit_counter; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE webpage_hit_counter WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE webpage_hit_counter OWNER TO admin;

\connect webpage_hit_counter

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: authn_login_show(character varying); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.authn_login_show(_user_email character varying) RETURNS TABLE(authn_login_id integer, user_email character varying, password_hash character varying, failed_attempts integer, blocked boolean)
    LANGUAGE plpgsql
    AS $$
declare

begin

return query 
select  t.authn_login_id,
    t.user_email,
    t.password_hash,
    t.failed_attempts,
    t.blocked
from authn_login t
where t.user_email = _user_email;

end; 
$$;


ALTER FUNCTION public.authn_login_show(_user_email character varying) OWNER TO admin;

--
-- Name: drop_function(text); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.drop_function(_name text, OUT functions_dropped integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
-- drop all functions with given _name regardless of function parameters
-- test it: create function test1. Then 
-- select drop_function('webpage_hits_delete');
DECLARE
   _sql text;
BEGIN
   SELECT count(*)::int
        , 'DROP FUNCTION ' || string_agg(oid::regprocedure::text, '; DROP FUNCTION ')
   FROM   pg_catalog.pg_proc
   WHERE  proname = _name
   AND    pg_function_is_visible(oid)  -- restrict to current search_path
   INTO   functions_dropped, _sql;     -- count only returned if subsequent DROPs succeed

   IF functions_dropped > 0 THEN       -- only if function(s) found
     EXECUTE _sql;
   END IF;
END
$$;


ALTER FUNCTION public.drop_function(_name text, OUT functions_dropped integer) OWNER TO admin;

--
-- Name: random_between(integer, integer); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.random_between(low integer, high integer) RETURNS integer
    LANGUAGE plpgsql STRICT
    AS $$
begin

return floor(random()* (high-low + 1) + low);

end;
$$;


ALTER FUNCTION public.random_between(low integer, high integer) OWNER TO admin;

--
-- Name: webpage_hits_delete(integer); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.webpage_hits_delete(_id integer) RETURNS TABLE(deleted_rows integer)
    LANGUAGE plpgsql
    AS $$
declare
begin

delete from hit_counter h
where h.webpage_id = _id;

delete from webpage w
where w.id = _id;

return query 
select 1 as deleted_rows;

end; 
$$;


ALTER FUNCTION public.webpage_hits_delete(_id integer) OWNER TO admin;

--
-- Name: webpage_hits_edit(integer); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.webpage_hits_edit(_id integer) RETURNS TABLE(id integer, webpage character varying, hit_count integer)
    LANGUAGE plpgsql
    AS $$
declare
begin

return query 
select w.id, w.webpage, w.hit_count
from webpage_hits w
where w.id=_id;

end; 
$$;


ALTER FUNCTION public.webpage_hits_edit(_id integer) OWNER TO admin;

--
-- Name: webpage_hits_insert(integer, character varying, integer); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.webpage_hits_insert(_id integer, _webpage character varying, _hit_count integer) RETURNS TABLE(id integer, webpage character varying, hit_count integer)
    LANGUAGE plpgsql
    AS $$
declare

begin

insert into webpage ( "id", webpage)
values (_id, _webpage);

insert into hit_counter(webpage_id, "count")
values(_id,_hit_count);

return query 
select w.id, w.webpage, w.hit_count
from webpage_hits w
where w.id=_id;

end; 
$$;


ALTER FUNCTION public.webpage_hits_insert(_id integer, _webpage character varying, _hit_count integer) OWNER TO admin;

--
-- Name: webpage_hits_new(); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.webpage_hits_new() RETURNS TABLE(id integer, webpage character varying, hit_count integer)
    LANGUAGE plpgsql
    AS $$
declare
begin
return query 

-- the id is random from one billion. that is enough for my simple tutorial.
select random_between(1, 1000000000) as id, 
'webpage short url'::varchar(100) as webpage, 
0 as hit_count;

end; 
$$;


ALTER FUNCTION public.webpage_hits_new() OWNER TO admin;

--
-- Name: webpage_hits_show(integer); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.webpage_hits_show(_id integer) RETURNS TABLE(id integer, webpage character varying, hit_count integer)
    LANGUAGE plpgsql
    AS $$
declare
begin

return query 
select w.id, w.webpage, w.hit_count
from webpage_hits w
where w.id=_id;

end; 
$$;


ALTER FUNCTION public.webpage_hits_show(_id integer) OWNER TO admin;

--
-- Name: webpage_hits_update(integer, character varying, integer); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.webpage_hits_update(_id integer, _webpage character varying, _hit_count integer) RETURNS TABLE(id integer, webpage character varying, hit_count integer)
    LANGUAGE plpgsql
    AS $$
declare
begin

update webpage as w
set webpage = _webpage
where w.id = _id;

update hit_counter as h
set count = _hit_count
where h.webpage_id=_id;

return query 
select W.id, W.webpage, W.hit_count
from webpage_hits W
where W.id=_id;

end; 
$$;


ALTER FUNCTION public.webpage_hits_update(_id integer, _webpage character varying, _hit_count integer) OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: authn_login; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.authn_login (
    authn_login_id integer NOT NULL,
    user_email character varying(100) NOT NULL,
    password_hash character varying(100) NOT NULL,
    failed_attempts integer DEFAULT 0 NOT NULL,
    blocked boolean DEFAULT false NOT NULL
);


ALTER TABLE public.authn_login OWNER TO admin;

--
-- Name: authn_login_authn_login_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.authn_login_authn_login_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.authn_login_authn_login_id_seq OWNER TO admin;

--
-- Name: authn_login_authn_login_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.authn_login_authn_login_id_seq OWNED BY public.authn_login.authn_login_id;


--
-- Name: hit_counter; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.hit_counter (
    id integer NOT NULL,
    webpage_id integer NOT NULL,
    count integer NOT NULL
);


ALTER TABLE public.hit_counter OWNER TO admin;

--
-- Name: hit_counter_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.hit_counter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hit_counter_id_seq OWNER TO admin;

--
-- Name: hit_counter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.hit_counter_id_seq OWNED BY public.hit_counter.id;


--
-- Name: list_all_function_input_params; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.list_all_function_input_params AS
 SELECT p.proname,
    pg_get_function_arguments(p.oid) AS args_def
   FROM pg_proc p
  WHERE (p.pronamespace <> ALL (ARRAY[(11)::oid, (13161)::oid]))
  ORDER BY p.proname;


ALTER TABLE public.list_all_function_input_params OWNER TO admin;

--
-- Name: list_all_view_fields; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.list_all_view_fields AS
 SELECT c.relname,
    a.attname,
    t.typname
   FROM ((pg_class c
     JOIN pg_attribute a ON ((a.attrelid = c.oid)))
     JOIN pg_type t ON ((t.oid = a.atttypid)))
  WHERE ((c.relkind = 'v'::"char") AND (c.relnamespace <> ALL (ARRAY[(11)::oid, (13161)::oid])));


ALTER TABLE public.list_all_view_fields OWNER TO admin;

--
-- Name: webpage; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.webpage (
    id integer NOT NULL,
    webpage character varying(100) NOT NULL
);


ALTER TABLE public.webpage OWNER TO admin;

--
-- Name: webpage_hits; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.webpage_hits AS
 SELECT w.id,
    w.webpage,
    h.count AS hit_count
   FROM (public.webpage w
     JOIN public.hit_counter h ON ((h.webpage_id = w.id)))
  WHERE (w.id = h.webpage_id)
  ORDER BY w.webpage;


ALTER TABLE public.webpage_hits OWNER TO admin;

--
-- Name: webpage_hits_list; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.webpage_hits_list AS
 SELECT w.id,
    w.webpage,
    w.hit_count
   FROM public.webpage_hits w;


ALTER TABLE public.webpage_hits_list OWNER TO admin;

--
-- Name: authn_login authn_login_id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.authn_login ALTER COLUMN authn_login_id SET DEFAULT nextval('public.authn_login_authn_login_id_seq'::regclass);


--
-- Name: hit_counter id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.hit_counter ALTER COLUMN id SET DEFAULT nextval('public.hit_counter_id_seq'::regclass);


--
-- Data for Name: authn_login; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.authn_login (authn_login_id, user_email, password_hash, failed_attempts, blocked) FROM stdin;
\.
COPY public.authn_login (authn_login_id, user_email, password_hash, failed_attempts, blocked) FROM '$$PATH$$/3039.dat';

--
-- Data for Name: hit_counter; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.hit_counter (id, webpage_id, count) FROM stdin;
\.
COPY public.hit_counter (id, webpage_id, count) FROM '$$PATH$$/3037.dat';

--
-- Data for Name: webpage; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.webpage (id, webpage) FROM stdin;
\.
COPY public.webpage (id, webpage) FROM '$$PATH$$/3035.dat';

--
-- Name: authn_login_authn_login_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.authn_login_authn_login_id_seq', 1, true);


--
-- Name: hit_counter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.hit_counter_id_seq', 8, true);


--
-- Name: authn_login authn_login_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.authn_login
    ADD CONSTRAINT authn_login_pkey PRIMARY KEY (authn_login_id);


--
-- Name: hit_counter hit_counter_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.hit_counter
    ADD CONSTRAINT hit_counter_pkey PRIMARY KEY (id);


--
-- Name: webpage webpage_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.webpage
    ADD CONSTRAINT webpage_pkey PRIMARY KEY (id);


--
-- Name: webpage webpage_uniq_webpage; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.webpage
    ADD CONSTRAINT webpage_uniq_webpage UNIQUE (webpage);


--
-- Name: hit_counter webpage; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.hit_counter
    ADD CONSTRAINT webpage FOREIGN KEY (webpage_id) REFERENCES public.webpage(id);


--
-- PostgreSQL database dump complete
--

